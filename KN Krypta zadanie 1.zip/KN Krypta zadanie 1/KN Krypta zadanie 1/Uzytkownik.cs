﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KN_Krypta_zadanie_1
{
    class Uzytkownik
    {
        public string nickname;
        Random rand = new Random();

        public void Comment(Komentarz com, List<Uzytkownik> users, int decision)
        {
            users.RemoveAll(p => p.nickname == nickname);

            

            Komentarz c = new Komentarz();
            int id = 0;
            switch (decision)
            {  
                case 1: 
                    c.msg = "komentarz" ;
                    c.author = nickname;
                    com.answer.Add(c);
                    break;
                case 2:
                    if(com.answer.Count() == 0)
                    {
                        c.msg = "komentarz +";
                        c.author = nickname;
                        com.answer.Add(c);
                    }
                    else
                    {
                        id = rand.Next(0, com.answer.Count());
                        c.msg = "odpowiedz";
                        c.author = nickname;
                        com.answer[id].answer.Add(c);
                    }  
                    break;
            }

            if(users.Count>0)
            {
                int nextUser = rand.Next(0, users.Count);
                int dec = rand.Next(1, 3);
                users[nextUser].Comment(com, users, dec);
            }
            else
            {
                Console.WriteLine("Message: " + com.msg);
                Console.WriteLine("Author: " + com.author);
                for(int i=0; i<com.answer.Count(); i++)
                {
                    Console.WriteLine("\tComment: " + com.answer[i].msg);
                    Console.WriteLine("\tAuthor: " + com.answer[i].author);
                    for(int y = 0; y < com.answer[i].answer.Count; y++)
                    {
                        Console.WriteLine("\t\tComment: " + com.answer[i].answer[y].msg);
                        Console.WriteLine("\t\tAuthor: " + com.answer[i].answer[y].author);
                    }
                }
            }
        }


    }
}
