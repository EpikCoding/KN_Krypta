﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KN_Krypta_zadanie_1
{
    class Program
    {

        List<Uzytkownik> users = new List<Uzytkownik>();
        public static void Main(string[] args)
        {
                Random rand = new Random();
                Program p = new Program();
                p.Init();
                Komentarz com = new Komentarz();
                com.msg = "WIADOMOSC";
                com.author = "OP";
                p.users[rand.Next(0, p.users.Count)].Comment(com, p.users, 1);
            
            


            Console.ReadKey();
        }

        void Init()
        {
            Random rand = new Random();
            int max = rand.Next(2, 50);
            for (int i = 1; i <= max; i++)
            {
                Uzytkownik u = new Uzytkownik();
                u.nickname = "User#" + i;
                users.Add(u);
            }
        }

    }
}
