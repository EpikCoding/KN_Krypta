﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KN_Krypta_zadanie_1
{
    class Komentarz
    {
        public int id;
        public string msg;
        public string author;
        public List<Komentarz> answer = new List<Komentarz>();
    }
}
